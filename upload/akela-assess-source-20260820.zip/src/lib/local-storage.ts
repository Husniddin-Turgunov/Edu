import "server-only";
import { existsSync } from "node:fs";
import { mkdir, readdir, readFile, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import type { DriveFile } from "@/lib/google-drive";

export const STORAGE_SUBDIRS = {
  tests: "tests",
  lessons: "lessons",
  attestations: "attestations",
  design: "design",
  employees: "employees",
  reports: "reports",
} as const;

export type StorageSubdir = (typeof STORAGE_SUBDIRS)[keyof typeof STORAGE_SUBDIRS];

const LOCAL_ID_PREFIX = "local::";

const EXCEL_EXT = /\.(xlsx|xls)$/i;
const WORD_EXT = /\.(docx|doc)$/i;

const MIME_BY_EXT: Record<string, string> = {
  ".xlsx":
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".xls": "application/vnd.ms-excel",
  ".docx":
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".doc": "application/msword",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".mov": "video/quicktime",
  ".m4v": "video/x-m4v",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
};

function mimeFromName(name: string) {
  return MIME_BY_EXT[path.extname(name).toLowerCase()] ?? "application/octet-stream";
}

function looksLikeExcel(name: string) {
  return EXCEL_EXT.test(name);
}

function looksLikeWord(name: string) {
  return WORD_EXT.test(name);
}

export function sanitizeFilename(name: string) {
  const base = path.basename(name).replace(/[^\w.\-()\u0400-\u04FF\s]/gi, "_");
  return base.slice(0, 180) || "file";
}

export function localFileId(relativePath: string) {
  return `${LOCAL_ID_PREFIX}${relativePath.replace(/\\/g, "/")}`;
}

export function isLocalFileId(id: string) {
  return id.startsWith(LOCAL_ID_PREFIX);
}

export function localRelativePath(id: string) {
  if (!isLocalFileId(id)) return null;
  return id.slice(LOCAL_ID_PREFIX.length);
}

/** Env override first, then DB integration setting, then dev fallback. */
export async function getStorageRoot(): Promise<string | null> {
  const envRoot = process.env.LOCAL_STORAGE_ROOT?.trim();
  if (envRoot) return path.resolve(envRoot);

  const { getStoredConfig } = await import("@/db/integrations");
  const config = await getStoredConfig("storage");
  const configured = config.localPath?.trim();
  if (configured) return path.resolve(configured);

  if (process.env.NODE_ENV === "development") {
    return path.resolve(process.cwd(), "data/storage");
  }

  return null;
}

export async function isLocalStorageConfigured() {
  const root = await getStorageRoot();
  return Boolean(root);
}

function assertInsideRoot(root: string, target: string) {
  const normalizedRoot = path.resolve(root);
  const normalizedTarget = path.resolve(target);
  if (
    normalizedTarget !== normalizedRoot &&
    !normalizedTarget.startsWith(`${normalizedRoot}${path.sep}`)
  ) {
    throw new Error("Invalid storage path");
  }
}

export async function ensureStorageLayout(root: string) {
  await mkdir(root, { recursive: true });
  await Promise.all(
    Object.values(STORAGE_SUBDIRS).map((dir) =>
      mkdir(path.join(root, dir), { recursive: true }),
    ),
  );
}

async function scanDirectory(
  root: string,
  subdir: StorageSubdir,
  predicate: (name: string) => boolean,
): Promise<DriveFile[]> {
  const dir = path.join(root, subdir);
  if (!existsSync(dir)) return [];

  const entries = await readdir(dir, { withFileTypes: true });
  const files: DriveFile[] = [];

  for (const entry of entries) {
    if (!entry.isFile()) continue;
    if (!predicate(entry.name)) continue;
    const relativePath = `${subdir}/${entry.name}`;
    const fullPath = path.join(root, relativePath);
    const info = await stat(fullPath);
    files.push({
      id: localFileId(relativePath),
      name: entry.name,
      modifiedTime: info.mtime.toISOString(),
      mimeType: mimeFromName(entry.name),
    });
  }

  return files.sort((a, b) => a.name.localeCompare(b.name, "ru"));
}

export async function listLocalExcelFiles(subdir: "tests" | "lessons" | "attestations") {
  const root = await getStorageRoot();
  if (!root) return [];
  await ensureStorageLayout(root);
  return scanDirectory(root, subdir, looksLikeExcel);
}

export async function listLocalWordFiles() {
  const root = await getStorageRoot();
  if (!root) return [];
  await ensureStorageLayout(root);
  return scanDirectory(root, STORAGE_SUBDIRS.lessons, looksLikeWord);
}

export async function listLocalLessonSourceFiles() {
  const [word, excel] = await Promise.all([
    listLocalWordFiles(),
    listLocalExcelFiles("lessons"),
  ]);
  const byId = new Map<string, DriveFile>();
  for (const file of [...word, ...excel]) byId.set(file.id, file);
  return [...byId.values()];
}

export async function readLocalFileById(id: string): Promise<Buffer> {
  const relative = localRelativePath(id);
  if (!relative) throw new Error("Not a local file id");
  return readLocalRelativePath(relative);
}

export async function readLocalRelativePath(relativePath: string): Promise<Buffer> {
  const root = await getStorageRoot();
  if (!root) throw new Error("Local storage is not configured");
  const fullPath = path.join(/* turbopackIgnore: true */ root, relativePath);
  assertInsideRoot(root, fullPath);
  return readFile(/* turbopackIgnore: true */ fullPath);
}

export async function writeLocalFile(input: {
  subdir: StorageSubdir | string;
  fileName: string;
  buffer: Buffer;
  randomSuffix?: boolean;
}) {
  const root = await getStorageRoot();
  if (!root) throw new Error("Local storage is not configured");
  await ensureStorageLayout(root);

  const safeName = sanitizeFilename(input.fileName);
  const base = input.randomSuffix
    ? `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeName}`
    : safeName;
  const relativePath = path.posix.join(input.subdir.replace(/\\/g, "/"), base);
  const fullPath = path.join(/* turbopackIgnore: true */ root, relativePath);
  assertInsideRoot(root, fullPath);
  await mkdir(path.dirname(fullPath), { recursive: true });
  await writeFile(/* turbopackIgnore: true */ fullPath, input.buffer);

  return {
    relativePath,
    id: localFileId(relativePath),
    url: `/api/files/${relativePath.split("/").map(encodeURIComponent).join("/")}`,
  };
}

export function publicFileUrl(relativePath: string) {
  return `/api/files/${relativePath.split("/").map(encodeURIComponent).join("/")}`;
}

export async function verifyLocalStorageAccess(): Promise<{
  ok: boolean;
  root: string | null;
  message: string;
}> {
  const root = await getStorageRoot();
  if (!root) {
    return {
      ok: false,
      root: null,
      message: "Локальный путь не задан (LOCAL_STORAGE_ROOT или Интеграции → Хранилище).",
    };
  }

  try {
    await ensureStorageLayout(root);
    const probe = path.join(root, ".write-test");
    await writeFile(probe, Buffer.from("ok"));
    await readFile(probe);
    return {
      ok: true,
      root,
      message: `Локальное хранилище доступно: ${root}`,
    };
  } catch (error) {
    return {
      ok: false,
      root,
      message: error instanceof Error ? error.message : String(error),
    };
  }
}
